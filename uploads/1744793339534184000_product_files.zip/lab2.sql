--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--1
SELECT
    COALESCE(city, 'Итого') AS city, 
    COALESCE(region, 'Итого') AS region,
    SUM(total_orders) AS sum_orders,
    SUM(total_revenue) AS sum_revenue
FROM pickup_points p
WHERE total_revenue > (
    SELECT AVG(total_revenue)
    FROM pickup_points
    WHERE region = p.region
)
GROUP BY ROLLUP(city, region);

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--2
WITH region_totals AS (
    SELECT region, SUM(total_revenue) AS region_total
    FROM pickup_points
    GROUP BY region
),
agg AS (
    SELECT region, city, SUM(total_revenue) AS revenue
    FROM pickup_points
    GROUP BY ROLLUP(region, city)
)
SELECT
    a.region, CASE WHEN a.city IS NULL THEN 'сумма' ELSE a.city END AS city, a.revenue
FROM agg a
LEFT JOIN region_totals rt ON a.region = rt.region
WHERE
    (
        a.region IS NULL 
        OR a.city IS NULL 
        OR a.revenue >= 0.1 * rt.region_total
    )
ORDER BY a.region, a.city;


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--3
WITH region_medians AS (
	SELECT 
		region,
		PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY total_orders) AS median_order
	FROM pickup_points
	GROUP BY region
)

SELECT
	COALESCE(P.city, 'Итого') AS city,
	COALESCE(P.region, 'Итого') AS region,
	SUM(P.total_orders) AS sum_orders
FROM pickup_points P
JOIN region_medians rm ON P.region = rm.region
WHERE P.total_orders > rm.median_order
GROUP BY CUBE(P.city, P.region);


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--4
WITH recent_points AS (
    SELECT * FROM pickup_points
    WHERE created_at >= NOW() - INTERVAL '6 months'
),
region_revenue AS (
    SELECT region, SUM(total_revenue) AS total_region_revenue FROM recent_points
    GROUP BY region
),
filtered_points AS (
    SELECT rp.*, rr.total_region_revenue FROM recent_points rp
    JOIN region_revenue rr ON rp.region = rr.region
    WHERE rp.total_revenue >= 0.2 * rr.total_region_revenue
),
ranked_points AS (
    SELECT fp.*, ROW_NUMBER() OVER (PARTITION BY region ORDER BY total_revenue DESC) AS rank 
    FROM filtered_points fp
)
SELECT id, name, city, region, total_orders, total_revenue, created_at FROM ranked_points
WHERE rank <= 3;


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--5

WITH region_stats AS (
    SELECT id, region, name, total_orders, total_revenue, created_at, AVG(total_orders) OVER (PARTITION BY region) AS avg_orders_in_region
    FROM pickup_points
)
SELECT region, name, total_revenue, 
    RANK() OVER (PARTITION BY region ORDER BY total_revenue DESC) AS revenue_rank
FROM region_stats
WHERE created_at <= NOW() - INTERVAL '2 years' AND total_orders > avg_orders_in_region 
ORDER BY region, revenue_rank;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--6
WITH revenue_differences AS (
  SELECT id, name, city, EXTRACT(YEAR FROM created_at) AS year, total_revenue,
    LAG(total_revenue) OVER (
      PARTITION BY city, EXTRACT(YEAR FROM created_at)
      ORDER BY created_at
    ) AS prev_revenue,
    total_revenue - LAG(total_revenue) OVER (
      PARTITION BY city, EXTRACT(YEAR FROM created_at)
      ORDER BY created_at
    ) AS revenue_diff
  FROM pickup_points
)
SELECT id, name, city, year, revenue_diff
FROM revenue_differences
WHERE prev_revenue IS NOT NULL AND revenue_diff > 0.1 * prev_revenue;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--7
CREATE TYPE working_schedule AS (
  opening_time TIME,
  closing_time TIME,
  weekend BOOLEAN
);
ALTER TABLE pickup_points
  ALTER COLUMN working_hours TYPE working_schedule USING
    (
      (working_hours->>'opening_time')::TIME,
      (working_hours->>'closing_time')::TIME,
      (working_hours->>'weekend')::BOOLEAN
    );
    
SELECT *
FROM pickup_points
WHERE (working_hours).opening_time < '08:00'
  AND (working_hours).closing_time > '22:00'
  AND (working_hours).weekend = true;


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--8
SELECT name, working_hours
FROM pickup_points p
WHERE (working_hours).weekend = true
  AND total_revenue > (
    SELECT AVG(total_revenue)
    FROM pickup_points
    WHERE city = p.city
  );

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--9
UPDATE pickup_points
SET working_hours = working_hours || '{"holiday_hours": null}'::jsonb
WHERE total_orders > 100
  AND NOT (working_hours ? 'holiday_hours');


SELECT id, name, working_hours
FROM pickup_points
WHERE total_orders > 100
  AND working_hours ? 'holiday_hours';
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--10
SELECT (working_hours->>'weekend')::boolean AS weekend,
       AVG(total_revenue) AS avg_revenue,
       COUNT(*) AS points_count
FROM pickup_points
GROUP BY (working_hours->>'weekend')::boolean
HAVING COUNT(*) > 5;
